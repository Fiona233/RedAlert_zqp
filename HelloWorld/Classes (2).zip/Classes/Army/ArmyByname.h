#ifndef ArmyByname_h
#define ArmyByName_h

/*
 
 Refinrey                   a       矿场 60
 ElectricPowerPlant         b       电厂 50
 Barracks                   c       兵营 100
 Cannon                     d       加农炮 40
 Tank                       e       坦克 50
 Sodlier                    f       大兵 20
 WarFactory                 g       战车工厂 150
 BattlePlane                h       战斗机 60
 Jet                        i       喷气机 40
 MissileWell                j       核弹井 400
 SoldierX                   k       特种兵 30
 RTank                      l       R型坦克 60
 TTank                      m       T型坦克 60
 
 
 
 
 
 */

#endif
